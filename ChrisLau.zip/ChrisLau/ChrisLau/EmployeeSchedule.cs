﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChrisLau
{
    public partial class EmployeeSchedule : Form
    {
        public EmployeeSchedule()
        {
            InitializeComponent();
        }

        private void employeeScheduleBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeScheduleBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.employeeScheduleDataSet);

        }

        private void EmployeeSchedule_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'employeeScheduleDataSet.EmployeeSchedule' table. You can move, or remove it, as needed.
            this.employeeScheduleTableAdapter.Fill(this.employeeScheduleDataSet.EmployeeSchedule);

        }
    }
}
