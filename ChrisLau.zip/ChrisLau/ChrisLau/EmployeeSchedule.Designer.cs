﻿namespace ChrisLau
{
    partial class EmployeeSchedule
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmployeeSchedule));
            System.Windows.Forms.Label scheduleIDLabel;
            System.Windows.Forms.Label employeeIDLabel;
            System.Windows.Forms.Label shiftIDLabel;
            System.Windows.Forms.Label departmentIDLabel;
            System.Windows.Forms.Label daysLabel;
            System.Windows.Forms.Label frequencyLabel;
            this.employeeScheduleDataSet = new ChrisLau.EmployeeScheduleDataSet();
            this.employeeScheduleBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.employeeScheduleTableAdapter = new ChrisLau.EmployeeScheduleDataSetTableAdapters.EmployeeScheduleTableAdapter();
            this.tableAdapterManager = new ChrisLau.EmployeeScheduleDataSetTableAdapters.TableAdapterManager();
            this.employeeScheduleBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.employeeScheduleBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.scheduleIDTextBox = new System.Windows.Forms.TextBox();
            this.employeeIDTextBox = new System.Windows.Forms.TextBox();
            this.shiftIDTextBox = new System.Windows.Forms.TextBox();
            this.departmentIDTextBox = new System.Windows.Forms.TextBox();
            this.daysTextBox = new System.Windows.Forms.TextBox();
            this.frequencyTextBox = new System.Windows.Forms.TextBox();
            scheduleIDLabel = new System.Windows.Forms.Label();
            employeeIDLabel = new System.Windows.Forms.Label();
            shiftIDLabel = new System.Windows.Forms.Label();
            departmentIDLabel = new System.Windows.Forms.Label();
            daysLabel = new System.Windows.Forms.Label();
            frequencyLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.employeeScheduleDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeScheduleBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeScheduleBindingNavigator)).BeginInit();
            this.employeeScheduleBindingNavigator.SuspendLayout();
            this.SuspendLayout();
            // 
            // employeeScheduleDataSet
            // 
            this.employeeScheduleDataSet.DataSetName = "EmployeeScheduleDataSet";
            this.employeeScheduleDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // employeeScheduleBindingSource
            // 
            this.employeeScheduleBindingSource.DataMember = "EmployeeSchedule";
            this.employeeScheduleBindingSource.DataSource = this.employeeScheduleDataSet;
            // 
            // employeeScheduleTableAdapter
            // 
            this.employeeScheduleTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.EmployeeScheduleTableAdapter = this.employeeScheduleTableAdapter;
            this.tableAdapterManager.UpdateOrder = ChrisLau.EmployeeScheduleDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // employeeScheduleBindingNavigator
            // 
            this.employeeScheduleBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.employeeScheduleBindingNavigator.BindingSource = this.employeeScheduleBindingSource;
            this.employeeScheduleBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.employeeScheduleBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.employeeScheduleBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.employeeScheduleBindingNavigatorSaveItem});
            this.employeeScheduleBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.employeeScheduleBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.employeeScheduleBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.employeeScheduleBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.employeeScheduleBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.employeeScheduleBindingNavigator.Name = "employeeScheduleBindingNavigator";
            this.employeeScheduleBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.employeeScheduleBindingNavigator.Size = new System.Drawing.Size(800, 25);
            this.employeeScheduleBindingNavigator.TabIndex = 0;
            this.employeeScheduleBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 15);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // employeeScheduleBindingNavigatorSaveItem
            // 
            this.employeeScheduleBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.employeeScheduleBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("employeeScheduleBindingNavigatorSaveItem.Image")));
            this.employeeScheduleBindingNavigatorSaveItem.Name = "employeeScheduleBindingNavigatorSaveItem";
            this.employeeScheduleBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 23);
            this.employeeScheduleBindingNavigatorSaveItem.Text = "Save Data";
            this.employeeScheduleBindingNavigatorSaveItem.Click += new System.EventHandler(this.employeeScheduleBindingNavigatorSaveItem_Click);
            // 
            // scheduleIDLabel
            // 
            scheduleIDLabel.AutoSize = true;
            scheduleIDLabel.Location = new System.Drawing.Point(71, 56);
            scheduleIDLabel.Name = "scheduleIDLabel";
            scheduleIDLabel.Size = new System.Drawing.Size(69, 13);
            scheduleIDLabel.TabIndex = 1;
            scheduleIDLabel.Text = "Schedule ID:";
            // 
            // scheduleIDTextBox
            // 
            this.scheduleIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeScheduleBindingSource, "ScheduleID", true));
            this.scheduleIDTextBox.Location = new System.Drawing.Point(156, 53);
            this.scheduleIDTextBox.Name = "scheduleIDTextBox";
            this.scheduleIDTextBox.Size = new System.Drawing.Size(100, 20);
            this.scheduleIDTextBox.TabIndex = 2;
            // 
            // employeeIDLabel
            // 
            employeeIDLabel.AutoSize = true;
            employeeIDLabel.Location = new System.Drawing.Point(71, 82);
            employeeIDLabel.Name = "employeeIDLabel";
            employeeIDLabel.Size = new System.Drawing.Size(70, 13);
            employeeIDLabel.TabIndex = 3;
            employeeIDLabel.Text = "Employee ID:";
            // 
            // employeeIDTextBox
            // 
            this.employeeIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeScheduleBindingSource, "EmployeeID", true));
            this.employeeIDTextBox.Location = new System.Drawing.Point(156, 79);
            this.employeeIDTextBox.Name = "employeeIDTextBox";
            this.employeeIDTextBox.Size = new System.Drawing.Size(100, 20);
            this.employeeIDTextBox.TabIndex = 4;
            // 
            // shiftIDLabel
            // 
            shiftIDLabel.AutoSize = true;
            shiftIDLabel.Location = new System.Drawing.Point(71, 108);
            shiftIDLabel.Name = "shiftIDLabel";
            shiftIDLabel.Size = new System.Drawing.Size(45, 13);
            shiftIDLabel.TabIndex = 5;
            shiftIDLabel.Text = "Shift ID:";
            // 
            // shiftIDTextBox
            // 
            this.shiftIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeScheduleBindingSource, "ShiftID", true));
            this.shiftIDTextBox.Location = new System.Drawing.Point(156, 105);
            this.shiftIDTextBox.Name = "shiftIDTextBox";
            this.shiftIDTextBox.Size = new System.Drawing.Size(100, 20);
            this.shiftIDTextBox.TabIndex = 6;
            // 
            // departmentIDLabel
            // 
            departmentIDLabel.AutoSize = true;
            departmentIDLabel.Location = new System.Drawing.Point(71, 134);
            departmentIDLabel.Name = "departmentIDLabel";
            departmentIDLabel.Size = new System.Drawing.Size(79, 13);
            departmentIDLabel.TabIndex = 7;
            departmentIDLabel.Text = "Department ID:";
            // 
            // departmentIDTextBox
            // 
            this.departmentIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeScheduleBindingSource, "DepartmentID", true));
            this.departmentIDTextBox.Location = new System.Drawing.Point(156, 131);
            this.departmentIDTextBox.Name = "departmentIDTextBox";
            this.departmentIDTextBox.Size = new System.Drawing.Size(100, 20);
            this.departmentIDTextBox.TabIndex = 8;
            // 
            // daysLabel
            // 
            daysLabel.AutoSize = true;
            daysLabel.Location = new System.Drawing.Point(71, 160);
            daysLabel.Name = "daysLabel";
            daysLabel.Size = new System.Drawing.Size(34, 13);
            daysLabel.TabIndex = 9;
            daysLabel.Text = "Days:";
            // 
            // daysTextBox
            // 
            this.daysTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeScheduleBindingSource, "Days", true));
            this.daysTextBox.Location = new System.Drawing.Point(156, 157);
            this.daysTextBox.Name = "daysTextBox";
            this.daysTextBox.Size = new System.Drawing.Size(100, 20);
            this.daysTextBox.TabIndex = 10;
            // 
            // frequencyLabel
            // 
            frequencyLabel.AutoSize = true;
            frequencyLabel.Location = new System.Drawing.Point(71, 186);
            frequencyLabel.Name = "frequencyLabel";
            frequencyLabel.Size = new System.Drawing.Size(60, 13);
            frequencyLabel.TabIndex = 11;
            frequencyLabel.Text = "Frequency:";
            // 
            // frequencyTextBox
            // 
            this.frequencyTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeScheduleBindingSource, "Frequency", true));
            this.frequencyTextBox.Location = new System.Drawing.Point(156, 183);
            this.frequencyTextBox.Name = "frequencyTextBox";
            this.frequencyTextBox.Size = new System.Drawing.Size(100, 20);
            this.frequencyTextBox.TabIndex = 12;
            // 
            // EmployeeSchedule
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(scheduleIDLabel);
            this.Controls.Add(this.scheduleIDTextBox);
            this.Controls.Add(employeeIDLabel);
            this.Controls.Add(this.employeeIDTextBox);
            this.Controls.Add(shiftIDLabel);
            this.Controls.Add(this.shiftIDTextBox);
            this.Controls.Add(departmentIDLabel);
            this.Controls.Add(this.departmentIDTextBox);
            this.Controls.Add(daysLabel);
            this.Controls.Add(this.daysTextBox);
            this.Controls.Add(frequencyLabel);
            this.Controls.Add(this.frequencyTextBox);
            this.Controls.Add(this.employeeScheduleBindingNavigator);
            this.Name = "EmployeeSchedule";
            this.Text = "EmployeeSchedule";
            this.Load += new System.EventHandler(this.EmployeeSchedule_Load);
            ((System.ComponentModel.ISupportInitialize)(this.employeeScheduleDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeScheduleBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeScheduleBindingNavigator)).EndInit();
            this.employeeScheduleBindingNavigator.ResumeLayout(false);
            this.employeeScheduleBindingNavigator.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private EmployeeScheduleDataSet employeeScheduleDataSet;
        private System.Windows.Forms.BindingSource employeeScheduleBindingSource;
        private EmployeeScheduleDataSetTableAdapters.EmployeeScheduleTableAdapter employeeScheduleTableAdapter;
        private EmployeeScheduleDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator employeeScheduleBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton employeeScheduleBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox scheduleIDTextBox;
        private System.Windows.Forms.TextBox employeeIDTextBox;
        private System.Windows.Forms.TextBox shiftIDTextBox;
        private System.Windows.Forms.TextBox departmentIDTextBox;
        private System.Windows.Forms.TextBox daysTextBox;
        private System.Windows.Forms.TextBox frequencyTextBox;
    }
}