﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChrisLau
{
    public partial class Employee_Shift : Form
    {
        public Employee_Shift()
        {
            InitializeComponent();
        }

        private void shiftInfoBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.shiftInfoBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.employeeShiftDataSet);

        }

        private void Employee_Shift_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'employeeShiftDataSet.ShiftInfo' table. You can move, or remove it, as needed.
            this.shiftInfoTableAdapter.Fill(this.employeeShiftDataSet.ShiftInfo);

        }
    }
}
