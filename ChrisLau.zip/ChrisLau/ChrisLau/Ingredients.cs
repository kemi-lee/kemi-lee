﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChrisLau
{
    public partial class Ingredients : Form
    {
        public Ingredients()
        {
            InitializeComponent();
        }

        private void ingredientsInfoBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.ingredientsInfoBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.ingredientsDataSet);

        }

        private void Ingredients_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'ingredientsDataSet.ingredientsInfo' table. You can move, or remove it, as needed.
            this.ingredientsInfoTableAdapter.Fill(this.ingredientsDataSet.ingredientsInfo);

        }
    }
}
