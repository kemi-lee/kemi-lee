﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChrisLau
{
    public partial class Assets : Form
    {
        public Assets()
        {
            InitializeComponent();
        }

        private void assetsInfoBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.assetsInfoBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.assetsDataSet);

        }

        private void Assets_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'assetsDataSet.AssetsInfo' table. You can move, or remove it, as needed.
            this.assetsInfoTableAdapter.Fill(this.assetsDataSet.AssetsInfo);

        }
    }
}
