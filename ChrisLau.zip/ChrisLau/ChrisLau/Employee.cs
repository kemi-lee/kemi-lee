﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChrisLau
{
    public partial class Employee : Form
    {
        public Employee()
        {
            InitializeComponent();
        }

        private void employeeDataBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeDataBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.employeeDataSet);

        }

        private void Employeecs_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'employeeDataSet.EmployeeData' table. You can move, or remove it, as needed.
            this.employeeDataTableAdapter.Fill(this.employeeDataSet.EmployeeData);

        }
    }
}
