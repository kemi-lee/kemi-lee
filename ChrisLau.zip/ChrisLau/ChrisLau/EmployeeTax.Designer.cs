﻿namespace ChrisLau
{
    partial class EmployeeTax
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmployeeTax));
            System.Windows.Forms.Label taxIDLabel;
            System.Windows.Forms.Label employeeIDLabel;
            System.Windows.Forms.Label socialSecurityNumberLabel;
            System.Windows.Forms.Label taxRateLabel;
            System.Windows.Forms.Label payIDLabel;
            System.Windows.Forms.Label taxYearLabel;
            this.employeeTaxInfoDataSet = new ChrisLau.EmployeeTaxInfoDataSet();
            this.employeeTaxInfoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.employeeTaxInfoTableAdapter = new ChrisLau.EmployeeTaxInfoDataSetTableAdapters.EmployeeTaxInfoTableAdapter();
            this.tableAdapterManager = new ChrisLau.EmployeeTaxInfoDataSetTableAdapters.TableAdapterManager();
            this.employeeTaxInfoBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.employeeTaxInfoBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.taxIDTextBox = new System.Windows.Forms.TextBox();
            this.employeeIDTextBox = new System.Windows.Forms.TextBox();
            this.socialSecurityNumberTextBox = new System.Windows.Forms.TextBox();
            this.taxRateTextBox = new System.Windows.Forms.TextBox();
            this.payIDTextBox = new System.Windows.Forms.TextBox();
            this.taxYearTextBox = new System.Windows.Forms.TextBox();
            taxIDLabel = new System.Windows.Forms.Label();
            employeeIDLabel = new System.Windows.Forms.Label();
            socialSecurityNumberLabel = new System.Windows.Forms.Label();
            taxRateLabel = new System.Windows.Forms.Label();
            payIDLabel = new System.Windows.Forms.Label();
            taxYearLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.employeeTaxInfoDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeTaxInfoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeTaxInfoBindingNavigator)).BeginInit();
            this.employeeTaxInfoBindingNavigator.SuspendLayout();
            this.SuspendLayout();
            // 
            // employeeTaxInfoDataSet
            // 
            this.employeeTaxInfoDataSet.DataSetName = "EmployeeTaxInfoDataSet";
            this.employeeTaxInfoDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // employeeTaxInfoBindingSource
            // 
            this.employeeTaxInfoBindingSource.DataMember = "EmployeeTaxInfo";
            this.employeeTaxInfoBindingSource.DataSource = this.employeeTaxInfoDataSet;
            // 
            // employeeTaxInfoTableAdapter
            // 
            this.employeeTaxInfoTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.EmployeeTaxInfoTableAdapter = this.employeeTaxInfoTableAdapter;
            this.tableAdapterManager.UpdateOrder = ChrisLau.EmployeeTaxInfoDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // employeeTaxInfoBindingNavigator
            // 
            this.employeeTaxInfoBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.employeeTaxInfoBindingNavigator.BindingSource = this.employeeTaxInfoBindingSource;
            this.employeeTaxInfoBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.employeeTaxInfoBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.employeeTaxInfoBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.employeeTaxInfoBindingNavigatorSaveItem});
            this.employeeTaxInfoBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.employeeTaxInfoBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.employeeTaxInfoBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.employeeTaxInfoBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.employeeTaxInfoBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.employeeTaxInfoBindingNavigator.Name = "employeeTaxInfoBindingNavigator";
            this.employeeTaxInfoBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.employeeTaxInfoBindingNavigator.Size = new System.Drawing.Size(800, 25);
            this.employeeTaxInfoBindingNavigator.TabIndex = 0;
            this.employeeTaxInfoBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 15);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // employeeTaxInfoBindingNavigatorSaveItem
            // 
            this.employeeTaxInfoBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.employeeTaxInfoBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("employeeTaxInfoBindingNavigatorSaveItem.Image")));
            this.employeeTaxInfoBindingNavigatorSaveItem.Name = "employeeTaxInfoBindingNavigatorSaveItem";
            this.employeeTaxInfoBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 23);
            this.employeeTaxInfoBindingNavigatorSaveItem.Text = "Save Data";
            this.employeeTaxInfoBindingNavigatorSaveItem.Click += new System.EventHandler(this.employeeTaxInfoBindingNavigatorSaveItem_Click);
            // 
            // taxIDLabel
            // 
            taxIDLabel.AutoSize = true;
            taxIDLabel.Location = new System.Drawing.Point(67, 69);
            taxIDLabel.Name = "taxIDLabel";
            taxIDLabel.Size = new System.Drawing.Size(42, 13);
            taxIDLabel.TabIndex = 1;
            taxIDLabel.Text = "Tax ID:";
            // 
            // taxIDTextBox
            // 
            this.taxIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeTaxInfoBindingSource, "TaxID", true));
            this.taxIDTextBox.Location = new System.Drawing.Point(193, 66);
            this.taxIDTextBox.Name = "taxIDTextBox";
            this.taxIDTextBox.Size = new System.Drawing.Size(100, 20);
            this.taxIDTextBox.TabIndex = 2;
            // 
            // employeeIDLabel
            // 
            employeeIDLabel.AutoSize = true;
            employeeIDLabel.Location = new System.Drawing.Point(67, 95);
            employeeIDLabel.Name = "employeeIDLabel";
            employeeIDLabel.Size = new System.Drawing.Size(70, 13);
            employeeIDLabel.TabIndex = 3;
            employeeIDLabel.Text = "Employee ID:";
            // 
            // employeeIDTextBox
            // 
            this.employeeIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeTaxInfoBindingSource, "EmployeeID", true));
            this.employeeIDTextBox.Location = new System.Drawing.Point(193, 92);
            this.employeeIDTextBox.Name = "employeeIDTextBox";
            this.employeeIDTextBox.Size = new System.Drawing.Size(100, 20);
            this.employeeIDTextBox.TabIndex = 4;
            // 
            // socialSecurityNumberLabel
            // 
            socialSecurityNumberLabel.AutoSize = true;
            socialSecurityNumberLabel.Location = new System.Drawing.Point(67, 121);
            socialSecurityNumberLabel.Name = "socialSecurityNumberLabel";
            socialSecurityNumberLabel.Size = new System.Drawing.Size(120, 13);
            socialSecurityNumberLabel.TabIndex = 5;
            socialSecurityNumberLabel.Text = "Social Security Number:";
            // 
            // socialSecurityNumberTextBox
            // 
            this.socialSecurityNumberTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeTaxInfoBindingSource, "SocialSecurityNumber", true));
            this.socialSecurityNumberTextBox.Location = new System.Drawing.Point(193, 118);
            this.socialSecurityNumberTextBox.Name = "socialSecurityNumberTextBox";
            this.socialSecurityNumberTextBox.Size = new System.Drawing.Size(100, 20);
            this.socialSecurityNumberTextBox.TabIndex = 6;
            // 
            // taxRateLabel
            // 
            taxRateLabel.AutoSize = true;
            taxRateLabel.Location = new System.Drawing.Point(67, 147);
            taxRateLabel.Name = "taxRateLabel";
            taxRateLabel.Size = new System.Drawing.Size(54, 13);
            taxRateLabel.TabIndex = 7;
            taxRateLabel.Text = "Tax Rate:";
            // 
            // taxRateTextBox
            // 
            this.taxRateTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeTaxInfoBindingSource, "TaxRate", true));
            this.taxRateTextBox.Location = new System.Drawing.Point(193, 144);
            this.taxRateTextBox.Name = "taxRateTextBox";
            this.taxRateTextBox.Size = new System.Drawing.Size(100, 20);
            this.taxRateTextBox.TabIndex = 8;
            // 
            // payIDLabel
            // 
            payIDLabel.AutoSize = true;
            payIDLabel.Location = new System.Drawing.Point(67, 173);
            payIDLabel.Name = "payIDLabel";
            payIDLabel.Size = new System.Drawing.Size(42, 13);
            payIDLabel.TabIndex = 9;
            payIDLabel.Text = "Pay ID:";
            // 
            // payIDTextBox
            // 
            this.payIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeTaxInfoBindingSource, "PayID", true));
            this.payIDTextBox.Location = new System.Drawing.Point(193, 170);
            this.payIDTextBox.Name = "payIDTextBox";
            this.payIDTextBox.Size = new System.Drawing.Size(100, 20);
            this.payIDTextBox.TabIndex = 10;
            // 
            // taxYearLabel
            // 
            taxYearLabel.AutoSize = true;
            taxYearLabel.Location = new System.Drawing.Point(67, 199);
            taxYearLabel.Name = "taxYearLabel";
            taxYearLabel.Size = new System.Drawing.Size(53, 13);
            taxYearLabel.TabIndex = 11;
            taxYearLabel.Text = "Tax Year:";
            // 
            // taxYearTextBox
            // 
            this.taxYearTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeTaxInfoBindingSource, "TaxYear", true));
            this.taxYearTextBox.Location = new System.Drawing.Point(193, 196);
            this.taxYearTextBox.Name = "taxYearTextBox";
            this.taxYearTextBox.Size = new System.Drawing.Size(100, 20);
            this.taxYearTextBox.TabIndex = 12;
            // 
            // EmployeeTax
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(taxIDLabel);
            this.Controls.Add(this.taxIDTextBox);
            this.Controls.Add(employeeIDLabel);
            this.Controls.Add(this.employeeIDTextBox);
            this.Controls.Add(socialSecurityNumberLabel);
            this.Controls.Add(this.socialSecurityNumberTextBox);
            this.Controls.Add(taxRateLabel);
            this.Controls.Add(this.taxRateTextBox);
            this.Controls.Add(payIDLabel);
            this.Controls.Add(this.payIDTextBox);
            this.Controls.Add(taxYearLabel);
            this.Controls.Add(this.taxYearTextBox);
            this.Controls.Add(this.employeeTaxInfoBindingNavigator);
            this.Name = "EmployeeTax";
            this.Text = "EmployeeTax";
            this.Load += new System.EventHandler(this.EmployeeTax_Load);
            ((System.ComponentModel.ISupportInitialize)(this.employeeTaxInfoDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeTaxInfoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeTaxInfoBindingNavigator)).EndInit();
            this.employeeTaxInfoBindingNavigator.ResumeLayout(false);
            this.employeeTaxInfoBindingNavigator.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private EmployeeTaxInfoDataSet employeeTaxInfoDataSet;
        private System.Windows.Forms.BindingSource employeeTaxInfoBindingSource;
        private EmployeeTaxInfoDataSetTableAdapters.EmployeeTaxInfoTableAdapter employeeTaxInfoTableAdapter;
        private EmployeeTaxInfoDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator employeeTaxInfoBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton employeeTaxInfoBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox taxIDTextBox;
        private System.Windows.Forms.TextBox employeeIDTextBox;
        private System.Windows.Forms.TextBox socialSecurityNumberTextBox;
        private System.Windows.Forms.TextBox taxRateTextBox;
        private System.Windows.Forms.TextBox payIDTextBox;
        private System.Windows.Forms.TextBox taxYearTextBox;
    }
}