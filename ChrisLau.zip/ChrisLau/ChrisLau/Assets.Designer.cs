﻿namespace ChrisLau
{
    partial class Assets
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Assets));
            System.Windows.Forms.Label assetIDLabel;
            System.Windows.Forms.Label assetTypeLabel;
            System.Windows.Forms.Label quantityLabel;
            System.Windows.Forms.Label conditionLabel;
            System.Windows.Forms.Label locationLabel;
            this.assetsDataSet = new ChrisLau.AssetsDataSet();
            this.assetsInfoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.assetsInfoTableAdapter = new ChrisLau.AssetsDataSetTableAdapters.AssetsInfoTableAdapter();
            this.tableAdapterManager = new ChrisLau.AssetsDataSetTableAdapters.TableAdapterManager();
            this.assetsInfoBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.assetsInfoBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.assetIDTextBox = new System.Windows.Forms.TextBox();
            this.assetTypeTextBox = new System.Windows.Forms.TextBox();
            this.quantityTextBox = new System.Windows.Forms.TextBox();
            this.conditionTextBox = new System.Windows.Forms.TextBox();
            this.locationTextBox = new System.Windows.Forms.TextBox();
            assetIDLabel = new System.Windows.Forms.Label();
            assetTypeLabel = new System.Windows.Forms.Label();
            quantityLabel = new System.Windows.Forms.Label();
            conditionLabel = new System.Windows.Forms.Label();
            locationLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.assetsDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetsInfoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetsInfoBindingNavigator)).BeginInit();
            this.assetsInfoBindingNavigator.SuspendLayout();
            this.SuspendLayout();
            // 
            // assetsDataSet
            // 
            this.assetsDataSet.DataSetName = "AssetsDataSet";
            this.assetsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // assetsInfoBindingSource
            // 
            this.assetsInfoBindingSource.DataMember = "AssetsInfo";
            this.assetsInfoBindingSource.DataSource = this.assetsDataSet;
            // 
            // assetsInfoTableAdapter
            // 
            this.assetsInfoTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AssetsInfoTableAdapter = this.assetsInfoTableAdapter;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.UpdateOrder = ChrisLau.AssetsDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // assetsInfoBindingNavigator
            // 
            this.assetsInfoBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.assetsInfoBindingNavigator.BindingSource = this.assetsInfoBindingSource;
            this.assetsInfoBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.assetsInfoBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.assetsInfoBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.assetsInfoBindingNavigatorSaveItem});
            this.assetsInfoBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.assetsInfoBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.assetsInfoBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.assetsInfoBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.assetsInfoBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.assetsInfoBindingNavigator.Name = "assetsInfoBindingNavigator";
            this.assetsInfoBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.assetsInfoBindingNavigator.Size = new System.Drawing.Size(800, 25);
            this.assetsInfoBindingNavigator.TabIndex = 0;
            this.assetsInfoBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 15);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // assetsInfoBindingNavigatorSaveItem
            // 
            this.assetsInfoBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.assetsInfoBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("assetsInfoBindingNavigatorSaveItem.Image")));
            this.assetsInfoBindingNavigatorSaveItem.Name = "assetsInfoBindingNavigatorSaveItem";
            this.assetsInfoBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 23);
            this.assetsInfoBindingNavigatorSaveItem.Text = "Save Data";
            this.assetsInfoBindingNavigatorSaveItem.Click += new System.EventHandler(this.assetsInfoBindingNavigatorSaveItem_Click);
            // 
            // assetIDLabel
            // 
            assetIDLabel.AutoSize = true;
            assetIDLabel.Location = new System.Drawing.Point(79, 144);
            assetIDLabel.Name = "assetIDLabel";
            assetIDLabel.Size = new System.Drawing.Size(50, 13);
            assetIDLabel.TabIndex = 1;
            assetIDLabel.Text = "Asset ID:";
            // 
            // assetIDTextBox
            // 
            this.assetIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.assetsInfoBindingSource, "AssetID", true));
            this.assetIDTextBox.Location = new System.Drawing.Point(148, 141);
            this.assetIDTextBox.Name = "assetIDTextBox";
            this.assetIDTextBox.Size = new System.Drawing.Size(100, 20);
            this.assetIDTextBox.TabIndex = 2;
            // 
            // assetTypeLabel
            // 
            assetTypeLabel.AutoSize = true;
            assetTypeLabel.Location = new System.Drawing.Point(79, 170);
            assetTypeLabel.Name = "assetTypeLabel";
            assetTypeLabel.Size = new System.Drawing.Size(63, 13);
            assetTypeLabel.TabIndex = 3;
            assetTypeLabel.Text = "Asset Type:";
            // 
            // assetTypeTextBox
            // 
            this.assetTypeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.assetsInfoBindingSource, "AssetType", true));
            this.assetTypeTextBox.Location = new System.Drawing.Point(148, 167);
            this.assetTypeTextBox.Name = "assetTypeTextBox";
            this.assetTypeTextBox.Size = new System.Drawing.Size(100, 20);
            this.assetTypeTextBox.TabIndex = 4;
            // 
            // quantityLabel
            // 
            quantityLabel.AutoSize = true;
            quantityLabel.Location = new System.Drawing.Point(79, 196);
            quantityLabel.Name = "quantityLabel";
            quantityLabel.Size = new System.Drawing.Size(49, 13);
            quantityLabel.TabIndex = 5;
            quantityLabel.Text = "Quantity:";
            // 
            // quantityTextBox
            // 
            this.quantityTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.assetsInfoBindingSource, "Quantity", true));
            this.quantityTextBox.Location = new System.Drawing.Point(148, 193);
            this.quantityTextBox.Name = "quantityTextBox";
            this.quantityTextBox.Size = new System.Drawing.Size(100, 20);
            this.quantityTextBox.TabIndex = 6;
            // 
            // conditionLabel
            // 
            conditionLabel.AutoSize = true;
            conditionLabel.Location = new System.Drawing.Point(79, 222);
            conditionLabel.Name = "conditionLabel";
            conditionLabel.Size = new System.Drawing.Size(54, 13);
            conditionLabel.TabIndex = 7;
            conditionLabel.Text = "Condition:";
            // 
            // conditionTextBox
            // 
            this.conditionTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.assetsInfoBindingSource, "Condition", true));
            this.conditionTextBox.Location = new System.Drawing.Point(148, 219);
            this.conditionTextBox.Name = "conditionTextBox";
            this.conditionTextBox.Size = new System.Drawing.Size(100, 20);
            this.conditionTextBox.TabIndex = 8;
            // 
            // locationLabel
            // 
            locationLabel.AutoSize = true;
            locationLabel.Location = new System.Drawing.Point(79, 248);
            locationLabel.Name = "locationLabel";
            locationLabel.Size = new System.Drawing.Size(51, 13);
            locationLabel.TabIndex = 9;
            locationLabel.Text = "Location:";
            // 
            // locationTextBox
            // 
            this.locationTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.assetsInfoBindingSource, "Location", true));
            this.locationTextBox.Location = new System.Drawing.Point(148, 245);
            this.locationTextBox.Name = "locationTextBox";
            this.locationTextBox.Size = new System.Drawing.Size(100, 20);
            this.locationTextBox.TabIndex = 10;
            // 
            // Assets
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(assetIDLabel);
            this.Controls.Add(this.assetIDTextBox);
            this.Controls.Add(assetTypeLabel);
            this.Controls.Add(this.assetTypeTextBox);
            this.Controls.Add(quantityLabel);
            this.Controls.Add(this.quantityTextBox);
            this.Controls.Add(conditionLabel);
            this.Controls.Add(this.conditionTextBox);
            this.Controls.Add(locationLabel);
            this.Controls.Add(this.locationTextBox);
            this.Controls.Add(this.assetsInfoBindingNavigator);
            this.Name = "Assets";
            this.Text = "Assets";
            this.Load += new System.EventHandler(this.Assets_Load);
            ((System.ComponentModel.ISupportInitialize)(this.assetsDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetsInfoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetsInfoBindingNavigator)).EndInit();
            this.assetsInfoBindingNavigator.ResumeLayout(false);
            this.assetsInfoBindingNavigator.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private AssetsDataSet assetsDataSet;
        private System.Windows.Forms.BindingSource assetsInfoBindingSource;
        private AssetsDataSetTableAdapters.AssetsInfoTableAdapter assetsInfoTableAdapter;
        private AssetsDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator assetsInfoBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton assetsInfoBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox assetIDTextBox;
        private System.Windows.Forms.TextBox assetTypeTextBox;
        private System.Windows.Forms.TextBox quantityTextBox;
        private System.Windows.Forms.TextBox conditionTextBox;
        private System.Windows.Forms.TextBox locationTextBox;
    }
}