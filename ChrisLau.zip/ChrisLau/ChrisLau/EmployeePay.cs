﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChrisLau
{
    public partial class EmployeePay : Form
    {
        public EmployeePay()
        {
            InitializeComponent();
        }

        private void empPayInfoBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.empPayInfoBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.empPayInfoDataSet);

        }

        private void EmployeePay_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'empPayInfoDataSet.EmpPayInfo' table. You can move, or remove it, as needed.
            this.empPayInfoTableAdapter.Fill(this.empPayInfoDataSet.EmpPayInfo);

        }
    }
}
